function [theta_music,g_hat] = fun_Twostage_DOA_GPE_MA(Y,model)
M = model.N;
Nc = model.Nc;
M_2 = M/2;
T = model.T;
L = 1;
R = (Y*Y')/T;
[E, Mu] = eig(R);
[~, id] = sort(diag(Mu),'descend');
E = E(:, id); 
E_S = E(:, 1:L);
E_S1 = E_S([1: M_2-1, M_2+1: end-1],: ); % Eq 7
E_S2 = E_S([2: M_2, M_2+2: end], :); % Eq 7
X1 = E_S1*pinv(E_S1' *E_S1)*E_S1';
PS_1 = eye(size(X1)) - X1;
X2 = E_S2*E_S2';
Q = X2.' .*PS_1;
Q = Q + 1e-10*eye(size(Q));
W = [eye(Nc - 1); zeros(M - Nc - 1, Nc - 1)]; %Eq 16
gamma_bar_hat = pinv(Q)*W*pinv(W' *pinv(Q)*W)*ones(Nc - 1, 1); %Eq 19
gamma_hat = zeros(M-Nc,1);
for i = 1 : M-Nc-1
    gamma_hat(i) = 1/(prod(gamma_bar_hat(Nc - 1: Nc - 1 + i))); %Eq 20
end
gamma_hat2 = [ones(Nc+1,1); gamma_hat(1:end-1)];
G_hat = diag(gamma_hat2);
g_hat = diag(G_hat);
R2 = inv(G_hat)*R*inv(G_hat'); % Eq 24
theta_music = fun_1D_MUSIC_single(R2,model);

end