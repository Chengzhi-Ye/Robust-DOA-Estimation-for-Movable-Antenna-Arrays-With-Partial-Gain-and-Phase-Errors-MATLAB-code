clc; clear; 
N = 16;
T = 1;    
f = 7e9; 
c = 3e8; 
Lambda = c/f;
d = Lambda/2;
theta = 45;       
u = cosd(theta);
beta = 1;
A = 10 * Lambda; 
Nc = 8;  % Nc = Mc - 1
SNR = 20;
len = 9001;
pos = zeros(N, 1);
for i = 1:N/2
    pos(i) = d*(i-1);
end
for k = (N/2+1):N
    pos(k) = A - d*(N-k);
end
model.N = N;
model.Lambda = Lambda;
model.d = d;
model.T = T;
model.Nc = Nc;
model.len = len;
model_ma = model;   
model_ma.pos = pos;
% GPE
g = 1 + sqrt(12)*0.1*(rand(N-Nc,1)-0.5);
varphi = exp(-1j*sqrt(12)*40*pi/180 *(rand(N-Nc, 1)-0.5));
ga = g .* varphi;
ga(1) = 1; %Mc = Nc + 1
gamma_true = [ones(Nc,1); ga]; 
G = diag(gamma_true);
P = 1;
s = P * exp(1i*2*pi*rand(1,T));
h_pos = beta * exp(1i*2*pi/Lambda * model_ma.pos * u);
Y_pos = awgn(G * h_pos * s, SNR, "measured");
[theta_est_ma, g_hat] = fun_Twostage_DOA_GPE_MA(Y_pos, model_ma);
fprintf('  > DOA _MA: %.4f° (RMSE: %.4e°)\n', theta_est_ma, sqrt(abs(theta_est_ma - theta).^2));
fprintf('  > GPE : %.4e (NMSE)\n', norm(g_hat - gamma_true)^2 / norm(gamma_true)^2);
