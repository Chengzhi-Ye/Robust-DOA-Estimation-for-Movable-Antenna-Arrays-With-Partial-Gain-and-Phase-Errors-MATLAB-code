function [theta_est,f_fun] = fun_1D_MUSIC_single(R_Y,model)
Lambda = model.Lambda;
len = model.len;
pos = model.pos;
beta = 1;
[U,~,~] = svd(R_Y);
U_z = U(: ,2: end);
f_fun = zeros(len, 1);
grid_theta=linspace(0,180,len);
for i = 1:length(grid_theta)
    alpha_tilde(:, i) = beta*exp(1i*2*pi/Lambda*pos*cosd(grid_theta(i)));
end
for i = 1:length(grid_theta)
    f_fun(i) = 1/real((alpha_tilde(:,i)' *(U_z*U_z')*alpha_tilde(: ,i)));
end
[~,theta_est] = max(f_fun);
theta_est = (theta_est-1)/((len-1)/180);
end